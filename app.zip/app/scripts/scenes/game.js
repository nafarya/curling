export default class Game extends Phaser.Scene {
  /**
   *  A sample Game scene, displaying the Phaser logo.
   *
   *  @extends Phaser.Scene
   */
  constructor() {
    super({key: 'Game'});

  }

  preload() {
    //  Display cover and progress bar textures.
    // this.load.image('splash', '123123.png');

    const x = this.cameras.main.width  / 2 ;
    const y = this.cameras.main.height / 4;

    this.circle = this.add
      .image(x, y, 'circle')
      .setScale(0.253);
  }

  /**
   *  Called when a scene is initialized. Method responsible for setting up
   *  the game objects of the scene.
   *
   *  @protected
   *  @param {object} data Initialization parameters.
   */
  create(/* data */) {
    //  TODO: Replace this content with really cool game code here :)]
    // this.logo = this.add.existing(new Logo(this));

    this.ball1 = this.physics.add.image(this.cameras.main.width / 2, 570, 'stone').setScale(0.23);
    // this.ball2 = this.physics.add.image(700, 240, 'stone').setScale(1/2);


    this.ball1.setCircle(75);
    this.ball1.setCollideWorldBounds(true);
    this.ball1.setBounce(1);
    this.ball1.setVelocity(0);
    this.ball1.setInteractive();

    this.input.setDraggable(this.ball1);

    this.input.on('dragend', (pointer, gameObject) => {
      var speedX = -(gameObject.x - pointer.x) * 1.5;
      var speedY = -(gameObject.y - pointer.y) * 1.5;
      gameObject.setVelocity(speedX, speedY);
      // this.input.setDraggable(gameObject, false);
    });
    // this.physics.add.collider(this.ball1);
    //  HINT: Declare all game assets to be loaded here.
  }

  /**
   *  Called when a scene is updated. Updates to game logic, physics and game
   *  objects are handled here.
   *
   *  @protected
   *  @param {number} t Current internal clock time.
   *  @param {number} dt Time elapsed since last update.
   */
  update(/* t, dt */) {
    // this.logo.update();
    var speedX = this.ball1.body.velocity.x * 0.995;
    var speedY = this.ball1.body.velocity.y * 0.995;

    if (speedX !== 0 || speedY !== 0) {
      this.ball1.angle += 0.1 * Math.sqrt(speedX * speedX + speedY * speedY);
    }

    this.ball1.setVelocity(speedX, speedY);

    if (Math.abs(this.ball1.body.velocity.x) < 1 && Math.abs(this.ball1.body.velocity.y) < 1) {

      this.ball1.setVelocity(0);
    }

    // this.sleep(100);

    // console.log(this.getDist(this.circle, this.ball1));
  }

  getDist(point1, point2) {
    return Math.sqrt(this.sqr(point1.x - point2.x) +  this.sqr(point1.y - point2.y));
  }

  sqr(x) {
    return x * x;
  }
}
